-- =====================================================
-- SCRIPT DE CRIAÇÃO DO BANCO DE DADOS
-- Sistema de Avaliação de Fornecedores - TCC
-- PostgreSQL
-- =====================================================

-- Criar tabela de Fornecedores
CREATE TABLE fornecedores (
    id SERIAL PRIMARY KEY,
    codigo_material VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    pais VARCHAR(100),
    comprador VARCHAR(100),
    gestor_qualidade VARCHAR(100),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar tabela de Critérios de Qualidade
CREATE TABLE criterios_qualidade (
    id SERIAL PRIMARY KEY,
    fornecedor_id INTEGER NOT NULL REFERENCES fornecedores(id) ON DELETE CASCADE,
    c1_status_contratual INTEGER DEFAULT 0,           -- max 25 pontos
    c2_negotiation_target INTEGER DEFAULT 0,          -- max 25 pontos
    c3_competitiveness INTEGER DEFAULT 0,             -- max 5 pontos
    c4_payment_terms INTEGER DEFAULT 0,               -- max 20 pontos
    c5_communication INTEGER DEFAULT 0,               -- max 10 pontos
    data_avaliacao DATE DEFAULT CURRENT_DATE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar tabela de Critérios de Entrega
CREATE TABLE criterios_entrega (
    id SERIAL PRIMARY KEY,
    fornecedor_id INTEGER NOT NULL REFERENCES fornecedores(id) ON DELETE CASCADE,
    d1_adherence_schedule INTEGER DEFAULT 0,          -- max 25 pontos
    d2_conformity_seg INTEGER DEFAULT 0,              -- max 30 pontos
    d3_special_freights INTEGER DEFAULT 0,            -- max 20 pontos
    d4_packaging_labelling INTEGER DEFAULT 0,         -- max 10 pontos
    d5_communication INTEGER DEFAULT 0,               -- max 15 pontos
    data_avaliacao DATE DEFAULT CURRENT_DATE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar tabela de Avaliação Comercial
CREATE TABLE criterios_comercial (
    id SERIAL PRIMARY KEY,
    fornecedor_id INTEGER NOT NULL REFERENCES fornecedores(id) ON DELETE CASCADE,
    score_comercial INTEGER DEFAULT 0,                -- 0-100 pontos
    data_avaliacao DATE DEFAULT CURRENT_DATE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar tabela de Scorecard (agregada)
CREATE TABLE scorecard (
    id SERIAL PRIMARY KEY,
    fornecedor_id INTEGER NOT NULL REFERENCES fornecedores(id) ON DELETE CASCADE,
    score_qualidade INTEGER DEFAULT 0,                -- soma C1+C2+C3+C4+C5
    peso_qualidade DECIMAL(5,2) DEFAULT 40.00,       -- peso em %
    score_comercial INTEGER DEFAULT 0,                -- 0-100
    peso_comercial DECIMAL(5,2) DEFAULT 20.00,       -- peso em %
    score_entrega INTEGER DEFAULT 0,                  -- soma D1+D2+D3+D4+D5
    peso_entrega DECIMAL(5,2) DEFAULT 40.00,         -- peso em %
    score_final DECIMAL(10,2) DEFAULT 0,              -- cálculo final
    status VARCHAR(20) DEFAULT 'amarelo',             -- verde, amarelo, vermelho
    data_calculo DATE DEFAULT CURRENT_DATE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar índices para melhor performance
CREATE INDEX idx_fornecedor_codigo ON fornecedores(codigo_material);
CREATE INDEX idx_qualidade_fornecedor ON criterios_qualidade(fornecedor_id);
CREATE INDEX idx_entrega_fornecedor ON criterios_entrega(fornecedor_id);
CREATE INDEX idx_comercial_fornecedor ON criterios_comercial(fornecedor_id);
CREATE INDEX idx_scorecard_fornecedor ON scorecard(fornecedor_id);
CREATE INDEX idx_scorecard_status ON scorecard(status);

-- =====================================================
-- INSERÇÃO DE DADOS DE EXEMPLO (3 FORNECEDORES)
-- =====================================================

-- Fornecedor 1
INSERT INTO fornecedores (codigo_material, nome, pais, comprador, gestor_qualidade)
VALUES ('ITM-001', 'Fornecedor 1', 'Brasil', 'Enzo', 'Felipe');

INSERT INTO criterios_qualidade (fornecedor_id, c1_status_contratual, c2_negotiation_target, c3_competitiveness, c4_payment_terms, c5_communication)
VALUES (1, 25, 25, 5, 20, 10);

INSERT INTO criterios_entrega (fornecedor_id, d1_adherence_schedule, d2_conformity_seg, d3_special_freights, d4_packaging_labelling, d5_communication)
VALUES (1, 25, 30, 15, 10, 15);

INSERT INTO criterios_comercial (fornecedor_id, score_comercial)
VALUES (1, 85);

-- Fornecedor 2
INSERT INTO fornecedores (codigo_material, nome, pais, comprador, gestor_qualidade)
VALUES ('ITM-002', 'Fornecedor 2', 'Brasil', 'Enzo', 'Felipe');

INSERT INTO criterios_qualidade (fornecedor_id, c1_status_contratual, c2_negotiation_target, c3_competitiveness, c4_payment_terms, c5_communication)
VALUES (2, 25, 15, 10, 20, 20);

INSERT INTO criterios_entrega (fornecedor_id, d1_adherence_schedule, d2_conformity_seg, d3_special_freights, d4_packaging_labelling, d5_communication)
VALUES (2, 20, 25, 10, 10, 10);

INSERT INTO criterios_comercial (fornecedor_id, score_comercial)
VALUES (2, 90);

-- Fornecedor 3
INSERT INTO fornecedores (codigo_material, nome, pais, comprador, gestor_qualidade)
VALUES ('ITM-003', 'Fornecedor 3', 'Brasil', 'Enzo', 'Felipe');

INSERT INTO criterios_qualidade (fornecedor_id, c1_status_contratual, c2_negotiation_target, c3_competitiveness, c4_payment_terms, c5_communication)
VALUES (3, 25, 15, 5, 20, 20);

INSERT INTO criterios_entrega (fornecedor_id, d1_adherence_schedule, d2_conformity_seg, d3_special_freights, d4_packaging_labelling, d5_communication)
VALUES (3, 20, 25, 10, 10, 10);

INSERT INTO criterios_comercial (fornecedor_id, score_comercial)
VALUES (3, 85);

-- =====================================================
-- FUNÇÃO PARA CALCULAR SCORECARD AUTOMATICAMENTE
-- =====================================================

CREATE OR REPLACE FUNCTION calcular_scorecard(p_fornecedor_id INTEGER)
RETURNS TABLE (
    fornecedor_id INTEGER,
    score_qualidade INTEGER,
    score_comercial INTEGER,
    score_entrega INTEGER,
    score_final DECIMAL,
    status VARCHAR
) AS $$
DECLARE
    v_score_qualidade INTEGER;
    v_score_comercial INTEGER;
    v_score_entrega INTEGER;
    v_score_final DECIMAL;
    v_status VARCHAR;
    v_peso_qualidade DECIMAL := 0.40;
    v_peso_comercial DECIMAL := 0.20;
    v_peso_entrega DECIMAL := 0.40;
BEGIN
    -- Calcular Qualidade (soma de C1-C5)
    SELECT COALESCE(c1_status_contratual, 0) + 
           COALESCE(c2_negotiation_target, 0) + 
           COALESCE(c3_competitiveness, 0) + 
           COALESCE(c4_payment_terms, 0) + 
           COALESCE(c5_communication, 0)
    INTO v_score_qualidade
    FROM criterios_qualidade
    WHERE fornecedor_id = p_fornecedor_id
    ORDER BY data_avaliacao DESC
    LIMIT 1;

    -- Calcular Comercial
    SELECT COALESCE(score_comercial, 0)
    INTO v_score_comercial
    FROM criterios_comercial
    WHERE fornecedor_id = p_fornecedor_id
    ORDER BY data_avaliacao DESC
    LIMIT 1;

    -- Calcular Entrega (soma de D1-D5)
    SELECT COALESCE(d1_adherence_schedule, 0) + 
           COALESCE(d2_conformity_seg, 0) + 
           COALESCE(d3_special_freights, 0) + 
           COALESCE(d4_packaging_labelling, 0) + 
           COALESCE(d5_communication, 0)
    INTO v_score_entrega
    FROM criterios_entrega
    WHERE fornecedor_id = p_fornecedor_id
    ORDER BY data_avaliacao DESC
    LIMIT 1;

    -- Calcular Score Final (com pesos)
    v_score_final := (v_score_qualidade * v_peso_qualidade) + 
                     (v_score_comercial * v_peso_comercial) + 
                     (v_score_entrega * v_peso_entrega);

    -- Definir Status baseado no Score Final
    IF v_score_final >= 200 THEN
        v_status := 'verde';
    ELSIF v_score_final >= 120 THEN
        v_status := 'amarelo';
    ELSE
        v_status := 'vermelho';
    END IF;

    -- Atualizar tabela de Scorecard
    INSERT INTO scorecard (fornecedor_id, score_qualidade, score_comercial, score_entrega, score_final, status)
    VALUES (p_fornecedor_id, v_score_qualidade, v_score_comercial, v_score_entrega, v_score_final, v_status)
    ON CONFLICT (fornecedor_id) DO UPDATE SET
        score_qualidade = v_score_qualidade,
        score_comercial = v_score_comercial,
        score_entrega = v_score_entrega,
        score_final = v_score_final,
        status = v_status,
        atualizado_em = CURRENT_TIMESTAMP;

    RETURN QUERY SELECT p_fornecedor_id, v_score_qualidade, v_score_comercial, v_score_entrega, v_score_final, v_status;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- EXECUTAR CÁLCULOS PARA OS 3 FORNECEDORES
-- =====================================================

SELECT calcular_scorecard(1);
SELECT calcular_scorecard(2);
SELECT calcular_scorecard(3);

-- =====================================================
-- VERIFICAR DADOS INSERIDOS
-- =====================================================

SELECT * FROM fornecedores;
SELECT * FROM scorecard;
